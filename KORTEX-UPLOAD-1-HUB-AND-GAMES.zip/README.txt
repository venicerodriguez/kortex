KORTEX
The Codex Archive • Author: Venice D. Rodriguez
The Launchpad for Engineered Brilliance.

HOW TO OPEN
Upload this folder to an https web host, open the link, then use Install. Phones, tablets and TVs can install it from that link.

SIGN IN
Learners tap their name, then Yes. The Teacher signs in with the Teacher PIN (starter PIN: 1234; choose your own in Tools → 🔐 Crypto Shield). Forgot it? Tap 🗝️ Forgot PIN? and type the Teacher Recovery Code from the private Teacher Guide. Log Out is in the top bar, and every sign-in and game opened is kept in the log.

14 GAMES
The Codex Archive: ABC SPRINT, MONTAGE. The Atheneum Space: 365 SMARTY, PED. BLUEPRINTS. The Literati Nest: BALANGAY SIKHAY, PANTAS. The Apex Summit: WHIZ CUP, ARENA. The Decathlon Suite: GAUNTLET. The Cipher Node: HelixPDGM, KUE, SYNAPSE, CRYPTO CORE. PlaySphere: TACTICAL HQ.

ONE KORTEX FOR EVERYONE
The first screen has three doors: Learner (tap your name), Parent (choose your child, then type the family code) and Teacher (Teacher PIN).
Parents can view progress only; nothing can be changed. The Teacher side stays behind the Teacher PIN, and the games keep their no-cheating rules.

ON THE KORTEX HOME
🎯 Calibrated Quiz: ten questions at a time, and every answer moves the next question up or down to fit the learner.
👪 Parent Dashboard: Tools → Parent Dashboard → 📮 Family Update saves one small file for every family. Share it in the class group chat.
   Each family opens KORTEX-LEARNER → 👪 Parent → 📥 Accept Teacher's Update, types the code on its slip (🔑 Family Code Slips) and sees only its own child:
   progress summary, goals, recent results, Teacher notes and attendance alerts.

KORTEX TOOLS (TEACHER)
📋 Attendance: Present, Late, Absent, Excused; one record per learner per day, shared with every game's Attendance First. Reports with filters, trends, rates, charts, CSV and PDF; Class Attendance Goals.
✍️ Add Results by Hand: paper tests and activities away from the screen; counted in Analytics, MPS, rewards and reports. (The games no longer keep their own copy.)
🏆 Leaderboard and Rewards: XP (10 per correct first answer + 20 per win, × Easy 1 / Standard 1.5 / Expert 2), wins (a game of 5 or more answers at 75% or more), badges, seasons (term, monthly, quarterly, school year or manual; past seasons are archived, lifetime totals stay).
🎯 Learner Goals: XP, wins, score, games completed or badges; milestone notifications at 25, 50, 75 and 100%; a completed goal earns one certificate.
🎓 Goal Certificates: Classic, Modern, Celebration or your own template; search, filters, sort, select, single or bulk print, index CSV.
🔔 Attendance Alerts: Late, Absent, optional Excused, Low Attendance Rate; history with filters and a learner drill-down.
📈 Analytics Dashboard: From/To, game, difficulty, season and grouping; charts; Analytics CSV and PDF; Student PDF.
Restore checks a backup first, shows what will change, saves a safety backup, restores and checks every item.
The first time the Teacher signs in with the starter PIN, KORTEX asks for the Teacher's own PIN.

EVERY SCHOOL YEAR
Opening day changes every year with the DepEd order. When the order comes out, type the opening day and the term dates in 🛠️ Vector State → School Calendar.
KORTEX and all 14 games move to the new school year on the opening day you set, and the summatives follow your dates. Until then KORTEX stays on the current school year.
Analytics keeps past school years under School Year.
When a new school year begins, KORTEX welcomes it and offers Start New School Year (it saves a backup first).

CLOCK
12-hour time with AM/PM by default. Tools → 🌊 Phase Shift or 🔮 Spectrum Render switches to 24-hour (military) time in KORTEX and every game.

KORTEX TOOLS (Teacher only)
💎 Superposition Data: Analytics and Reports for all 14 games and the Calibrated Quiz, by Daily, Weekly, Monthly, End of Term and End of School Year, each with Print / Save PDF and an animated presentation.
💾 Qubit Registry: who used KORTEX, when, and which games they opened.
🛠️ Vector State: School Year and School Calendar.   🔗 Entangled Pairs: the class masterlist every game uses.
🔮 Spectrum Render: banner and clock.   🌊 Phase Shift: screen, sound and clock.   Teacher Greeting: your welcome and polo color.   🔐 Crypto Shield: Teacher PIN.   ❄️ Absolute Freeze: lock Tools.   🔬 Coherence Check: QA check.
🚀 Teleport Drive: backup, restore, 📤 Send Scores and 📥 Accept Scores from every game.   📜 Planck Ledger: Authorship Record.   🕳️ Zero State: reset game data.   ⓘ All About KORTEX: Data Privacy and Authorship.   🧭 Lost?: issue guide.

PRIVACY
Generic class list (Learner 1, 2, and so on). Safe to share with colleagues.

STORIES
library: Aether, Fable and Fiora, the story library (Lux Lit Compendium and HIRAYA). Open it from the Lux Lit Compendium or HIRAYA cover under Aether, Fable and Fiora in KORTEX.
